#ifndef CONFIG_H
#define CONFIG_H

#include <stdio.h>

void config_write(FILE *f);
void config_read(const char *cfg);

#endif
